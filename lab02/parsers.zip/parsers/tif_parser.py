"""Ручной парсинг TIFF (baseline).
Header (8 байт):
  byte order: 'II' (LE) или 'MM' (BE)
  magic: 42
  offset to first IFD (4 байта, порядок зависит от byte order)

IFD: count(2), затем count записей по 12 байт:
  tag(2), type(2), count(4), value/offset(4)
type: 1=BYTE,2=ASCII,3=SHORT,4=LONG,5=RATIONAL,...
Нужные теги:
  256 ImageWidth, 257 ImageLength (Height),
  258 BitsPerSample, 259 Compression,
  262 PhotometricInterpretation,
  282 XResolution, 283 YResolution, 296 ResolutionUnit
"""

import os
from .base import ImageInfo, read_exact, u16_le, u32_le, u16_be, u32_be

COMPRESSION = {
    1: "без сжатия", 2: "CCITT 1D", 5: "LZW", 6: "JPEG (old)",
    7: "JPEG", 32773: "PackBits", 8: "Deflate", 32946: "Deflate",
}

PHOTOMETRIC = {
    0: "WhiteIsZero", 1: "BlackIsZero", 2: "RGB", 3: "Palette",
    4: "Transparency Mask", 5: "CMYK", 6: "YCbCr",
}


def _read_value(f, endian, typ, count, value_bytes, base_offset):
    """Читаем значение тега: либо inline, либо по смещению."""
    sizes = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8}
    total = sizes.get(typ, 1) * count
    if total <= 4:
        data = value_bytes
    else:
        off = (u32_le(value_bytes) if endian == "<" else u32_be(value_bytes))
        f.seek(off)
        data = f.read(total)

    if typ == 3:    # SHORT
        unpack = u16_le if endian == "<" else u16_be
        return [unpack(data[i:i+2]) for i in range(0, total, 2)]
    if typ == 4:    # LONG
        unpack = u32_le if endian == "<" else u32_be
        return [unpack(data[i:i+4]) for i in range(0, total, 4)]
    if typ == 5:    # RATIONAL
        unpack = u32_le if endian == "<" else u32_be
        nums = [unpack(data[i:i+4]) for i in range(0, total, 4)]
        return [(nums[i], nums[i+1]) for i in range(0, len(nums), 2)]
    return list(data)


def parse(path: str) -> ImageInfo:
    info = ImageInfo(filename=os.path.basename(path), format="TIFF")
    info.file_size = os.path.getsize(path)

    with open(path, "rb") as f:
        header = read_exact(f, 8)
        if header[:2] == b"II":
            endian = "<"
            magic = u16_le(header[2:4])
            ifd_off = u32_le(header[4:8])
        elif header[:2] == b"MM":
            endian = ">"
            magic = u16_be(header[2:4])
            ifd_off = u32_be(header[4:8])
        else:
            info.status = "Файл повреждён: нет сигнатуры TIFF"
            return info

        if magic != 42:
            info.status = "Файл повреждён: неверный magic TIFF"
            return info

        if ifd_off <= 0 or ifd_off >= info.file_size:
            info.status = "Файл повреждён: некорректное смещение IFD"
            return info

        f.seek(ifd_off)
        count_bytes = f.read(2)
        n = (u16_le(count_bytes) if endian == "<" else u16_be(count_bytes))

        tags = {}
        for _ in range(n):
            entry = f.read(12)
            if len(entry) < 12:
                info.status = "Файл повреждён: обрыв в IFD"
                return info
            unpack16 = u16_le if endian == "<" else u16_be
            unpack32 = u32_le if endian == "<" else u32_be
            tag   = unpack16(entry[0:2])
            typ   = unpack16(entry[2:4])
            cnt   = unpack32(entry[4:8])
            valb  = entry[8:12]
            try:
                tags[tag] = _read_value(f, endian, typ, cnt, valb, ifd_off)
            except Exception:
                continue
            f.seek(ifd_off + 2 + (n) * 12)  # вернуть позицию после entry
            # Пересчёт: мы уже прочитали count*12 записей выше — это упрощённый путь,
            # который читает по одной записи и восстанавливает позицию.

        # Извлекаем данные
        def first(tag, default=None):
            v = tags.get(tag)
            return v[0] if v else default

        info.width  = first(256, 0)
        info.height = first(257, 0)
        bps = tags.get(258)
        if bps:
            info.bit_depth = sum(bps) if len(bps) > 1 else bps[0]

        compr = first(259, 1)
        info.compression = COMPRESSION.get(compr, f"код {compr}")

        photo = first(262, None)
        if photo is not None:
            info.color_type = PHOTOMETRIC.get(photo, f"код {photo}")
        elif info.bit_depth == 1:
            info.color_type = "Bilevel"
        else:
            info.color_type = "Grayscale"

        # Разрешение
        xres = tags.get(282)
        yres = tags.get(283)
        unit = first(296, 2)   # 2 = дюйм, 3 = см
        if xres and yres:
            xr = xres[0][0] / xres[0][1] if xres[0][1] else 0
            yr = yres[0][0] / yres[0][1] if yres[0][1] else 0
            if unit == 3:      # сантиметры -> дюймы
                xr *= 2.54
                yr *= 2.54
            info.dpi_x = round(xr, 2)
            info.dpi_y = round(yr, 2)

    return info