"""Ручной парсинг JPEG (JFIF).
Маркеры: 0xFF <marker>. Основные:
  SOI = FFD8  (начало)
  EOI = FFD9  (конец)
  SOF0..SOF3, SOF5..SOF7, SOF9..SOF11, SOF13..SOF15 — параметры кадра:
      length(2), precision(1), height(2), width(2), components(1), ...
  APP0 (JFIF): length(2), 'JFIF\\0', ver(2), units(1), xdens(2), ydens(2),...
      units: 0 = без единиц, 1 = точки/дюйм, 2 = точки/см
"""

import os
from .base import (ImageInfo, read_exact, u16_be, FileTooShortError)

SOF_MARKERS = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
               0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
COMPONENT_NAMES = {1: "Grayscale", 3: "YCbCr (цветное)", 4: "CMYK"}


def parse(path: str) -> ImageInfo:
    info = ImageInfo(filename=os.path.basename(path), format="JPEG")
    info.file_size = os.path.getsize(path)

    with open(path, "rb") as f:
        soi = f.read(2)
        if soi != b"\xFF\xD8":
            info.status = "Файл повреждён: нет маркера SOI"
            return info

        have_sof = False
        while True:
            # Пропускаем любые не-FF байты
            b = f.read(1)
            while b and b != b"\xFF":
                b = f.read(1)
            if not b:
                break
            marker = f.read(1)
            if not marker:
                break
            m = marker[0]
            # Заполняющие FF
            while m == 0xFF:
                marker = f.read(1)
                if not marker:
                    break
                m = marker[0]

            if m == 0xD9:           # EOI
                break
            if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
                continue            # маркеры без длины

            seg_len_bytes = f.read(2)
            if len(seg_len_bytes) < 2:
                info.status = "Файл повреждён: обрыв в сегменте"
                break
            seg_len = u16_be(seg_len_bytes) - 2
            if seg_len < 0:
                info.status = "Файл повреждён: некорректная длина сегмента"
                break
            seg = f.read(seg_len)
            if len(seg) < seg_len:
                info.status = "Файл повреждён: неполный сегмент"
                break

            # --- APP0 (JFIF) — плотность (DPI) ---
            if m == 0xE0 and seg[:5] == b"JFIF\x00":
                units = seg[7]
                xd = u16_be(seg[8:10])
                yd = u16_be(seg[10:12])
                if units == 1:
                    info.dpi_x, info.dpi_y = float(xd), float(yd)
                elif units == 2:
                    info.dpi_x = round(xd * 2.54, 2)
                    info.dpi_y = round(yd * 2.54, 2)
                else:
                    info.dpi_x = info.dpi_y = 0.0

            # --- SOF — размеры и глубина цвета ---
            elif m in SOF_MARKERS:
                if len(seg) < 6:
                    info.status = "Файл повреждён: короткий SOF"
                    break
                precision = seg[0]
                h = u16_be(seg[1:3])
                w = u16_be(seg[3:5])
                ncomp = seg[5]
                info.width = w
                info.height = h
                info.bit_depth = precision * ncomp
                info.color_type = COMPONENT_NAMES.get(ncomp, f"{ncomp} компонент(а)")
                info.compression = "DCT (JPEG, lossy)"
                have_sof = True

        # Проверка EOI в конце
        f.seek(-2, os.SEEK_END)
        tail = f.read(2)
        if tail != b"\xFF\xD9":
            info.status = "Файл повреждён: отсутствует маркер EOI (FF D9)"
        elif not have_sof:
            info.status = "Файл повреждён: нет SOF-маркера"

    return info