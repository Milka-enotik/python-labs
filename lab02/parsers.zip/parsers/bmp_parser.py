"""Ручной парсинг BMP.
Структура:
  BITMAPFILEHEADER (14 байт): 'BM', size(4), res1(2), res2(2), offBits(4)
  BITMAPINFOHEADER (40 байт): size(4), width(4), height(4), planes(2),
      bpp(2), compression(4), imageSize(4), xppm(4), yppm(4),
      clrUsed(4), clrImportant(4)
DPI = pixels-per-meter * 0.0254
"""

import os
from .base import (ImageInfo, read_exact, u16_le, u32_le, i32_le,
                   FileTooShortError)

COMPRESSION = {
    0: "BI_RGB (без сжатия)",
    1: "BI_RLE8 (RLE 8 бит)",
    2: "BI_RLE4 (RLE 4 бит)",
    3: "BI_BITFIELDS",
    4: "BI_JPEG",
    5: "BI_PNG",
}


def parse(path: str) -> ImageInfo:
    info = ImageInfo(filename=os.path.basename(path), format="BMP")
    info.file_size = os.path.getsize(path)

    with open(path, "rb") as f:
        # --- BITMAPFILEHEADER ---
        fh = read_exact(f, 14)
        if fh[0:2] != b"BM":
            info.status = "Файл повреждён: нет сигнатуры BM"
            return info
        file_size_hdr = u32_le(fh[2:6])
        off_bits = u32_le(fh[10:14])

        # --- BITMAPINFOHEADER (может быть и меньше, но нам нужно 40) ---
        ih = read_exact(f, 40)
        hdr_size  = u32_le(ih[0:4])
        width     = i32_le(ih[4:8])
        height    = i32_le(ih[8:12])
        bpp       = u16_le(ih[14:16])
        compr     = u32_le(ih[16:20])
        xppm      = i32_le(ih[24:28])
        yppm      = i32_le(ih[28:32])
        clr_used  = u32_le(ih[32:36])

        info.width = abs(width)
        info.height = abs(height)
        info.bit_depth = bpp
        info.compression = COMPRESSION.get(compr, f"Неизвестно ({compr})")
        info.dpi_x = round(xppm * 0.0254, 2) if xppm else 0.0
        info.dpi_y = round(yppm * 0.0254, 2) if yppm else 0.0

        # Валидация: размер файла должен быть >= заявленного в заголовке
        if file_size_hdr and info.file_size < file_size_hdr:
            info.status = "Файл повреждён: размер файла меньше указанного в заголовке"

        # Палитра: если bpp <= 8 — она есть
        if bpp <= 8:
            n_colors = clr_used if clr_used else (1 << bpp)
            info.color_type = "Indexed (палитра)"
            info.extra["colors_in_palette"] = n_colors
            info.extra["palette_offset"] = 14 + hdr_size
        elif bpp == 24:
            info.color_type = "TrueColor (24 бит)"
        elif bpp == 32:
            info.color_type = "TrueColor + Alpha (32 бит)"
        else:
            info.color_type = f"{bpp} бит"

    return info