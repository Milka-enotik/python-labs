"""Точка входа в Data/Parsing Layer.
По сигнатуре файла выбираем нужный парсер и вызываем его.
Сторонние библиотеки для чтения метаданных НЕ используются."""

from . import bmp_parser, png_parser, jpg_parser, gif_parser, tif_parser, pcx_parser
from .base import ImageInfo, sniff_format

PARSERS = {
    "BMP":  bmp_parser.parse,
    "PNG":  png_parser.parse,
    "JPEG": jpg_parser.parse,
    "GIF":  gif_parser.parse,
    "TIFF": tif_parser.parse,
    "PCX":  pcx_parser.parse,
}


def parse_file(path: str) -> ImageInfo:
    """Определить формат и распарсить файл. Возвращает ImageInfo."""
    try:
        with open(path, "rb") as f:
            head = f.read(16)
    except OSError as e:
        info = ImageInfo(filename=path, status=f"Ошибка доступа: {e}")
        return info

    fmt = sniff_format(head)
    if fmt not in PARSERS:
        info = ImageInfo(filename=path, format="?", status="Неизвестный формат")
        return info

    try:
        return PARSERS[fmt](path)
    except Exception as e:
        info = ImageInfo(filename=path, format=fmt,
                         status=f"Файл повреждён: {type(e).__name__}: {e}")
        return info