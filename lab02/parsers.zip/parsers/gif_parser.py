"""Ручной парсинг GIF.
Header: 'GIF87a' / 'GIF89a' (6 байт)
Logical Screen Descriptor (7 байт):
    width(2 LE), height(2 LE), packed(1), bg(1), aspect(1)
packed: bit7 = Global Color Table Flag
        bits 6..4 = Color Resolution
        bit3 = Sort flag
        bits 2..0 = Size of Global Color Table (N -> 2^(N+1) цветов)
"""

import os
from .base import ImageInfo, read_exact, u16_le


def parse(path: str) -> ImageInfo:
    info = ImageInfo(filename=os.path.basename(path), format="GIF")
    info.file_size = os.path.getsize(path)

    with open(path, "rb") as f:
        header = f.read(6)
        if header[:3] != b"GIF":
            info.status = "Файл повреждён: нет сигнатуры GIF"
            return info
        if header not in (b"GIF87a", b"GIF89a"):
            info.status = "Файл повреждён: неизвестная версия GIF"
            return info

        lsd = read_exact(f, 7)
        info.width  = u16_le(lsd[0:2])
        info.height = u16_le(lsd[2:4])
        packed = lsd[4]

        gct_flag = (packed >> 7) & 1
        color_res = ((packed >> 4) & 0x7) + 1
        gct_size = 2 ** (((packed) & 0x7) + 1) if gct_flag else 0

        info.bit_depth = color_res
        info.compression = "LZW"
        if gct_flag:
            info.color_type = "Indexed (палитра)"
            info.extra["colors_in_palette"] = gct_size
        else:
            info.color_type = "Indexed (локальная палитра)"

        # Проверка наличия трейлера 0x3B — сложно без полного обхода,
        # поэтому просто проверяем, что файл не пустой
        if info.file_size < 20:
            info.status = "Файл повреждён: слишком маленький файл"

    return info