"""Базовые утилиты для побайтового чтения.
Все парсеры читают файл как поток байтов через встроенный open(..., 'rb')."""

import struct
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ImageInfo:
    """Единая структура результата для всех форматов."""
    filename: str = ""
    format: str = ""              # JPEG / PNG / BMP / GIF / TIFF / PCX
    width: int = 0
    height: int = 0
    dpi_x: float = 0.0            # точек на дюйм по X
    dpi_y: float = 0.0
    bit_depth: int = 0            # бит на пиксель (глубина цвета)
    color_type: str = ""          # Grayscale / TrueColor / Indexed / ...
    compression: str = "—"        # тип сжатия (если применимо)
    file_size: int = 0
    extra: dict = field(default_factory=dict)   # доп. поля (палитра, матрица и т.п.)
    status: str = "OK"            # OK / Файл повреждён: <причина>
    error: Optional[str] = None   # текст ошибки


class FileTooShortError(Exception):
    pass


def read_exact(f, n: int) -> bytes:
    """Прочитать ровно n байт или бросить FileTooShortError."""
    data = f.read(n)
    if len(data) < n:
        raise FileTooShortError(f"Ожидалось {n} байт, получено {len(data)}")
    return data


def u16_le(b: bytes) -> int:
    return struct.unpack_from("<H", b)[0]

def u32_le(b: bytes) -> int:
    return struct.unpack_from("<I", b)[0]

def i32_le(b: bytes) -> int:
    return struct.unpack_from("<i", b)[0]

def u16_be(b: bytes) -> int:
    return struct.unpack_from(">H", b)[0]

def u32_be(b: bytes) -> int:
    return struct.unpack_from(">I", b)[0]


def sniff_format(head: bytes) -> str:
    """Определяем формат по сигнатуре (Magic Numbers)."""
    if head.startswith(b"\xFF\xD8\xFF"):
        return "JPEG"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "PNG"
    if head.startswith(b"BM"):
        return "BMP"
    if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
        return "GIF"
    if head.startswith(b"II*\x00") or head.startswith(b"MM\x00*"):
        return "TIFF"
    if len(head) >= 1 and head[0] == 0x0A:      # PCX: manufacturer=10
        return "PCX"
    return "UNKNOWN"