"""Ручной парсинг PCX.
Заголовок (128 байт):
  byte 0: manufacturer = 0x0A
  byte 1: version
  byte 2: encoding (0=raw, 1=RLE)
  byte 3: bits_per_pixel
  bytes 4..11: xmin, ymin, xmax, ymax (по 2 байта LE)
  bytes 12..15: hres, vres (по 2 байта LE)  — DPI по X / Y
  byte 16: 48-color palette flag
  byte 65: nplanes
  bytes 66..67: bytes_per_line
  byte 68: palette_info (1 = цветная палитра)
"""

import os
from .base import ImageInfo, read_exact, u16_le

VERSIONS = {0: "v2.5", 2: "v2.8 (palette)", 3: "v2.8 (default palette)",
            4: "v3.0 (или Paintbrush IV)", 5: "v3.0+"}


def parse(path: str) -> ImageInfo:
    info = ImageInfo(filename=os.path.basename(path), format="PCX")
    info.file_size = os.path.getsize(path)

    with open(path, "rb") as f:
        h = read_exact(f, 128)
        if h[0] != 0x0A:
            info.status = "Файл повреждён: нет сигнатуры PCX (0x0A)"
            return info

        version = h[1]
        encoding = h[2]
        bpp = h[3]
        xmin = u16_le(h[4:6])
        ymin = u16_le(h[6:8])
        xmax = u16_le(h[8:10])
        ymax = u16_le(h[10:12])
        hres = u16_le(h[12:14])
        vres = u16_le(h[14:16])
        nplanes = h[65]
        bytes_per_line = u16_le(h[66:68])

        info.width  = xmax - xmin + 1
        info.height = ymax - ymin + 1
        info.bit_depth = bpp * nplanes
        info.dpi_x = float(hres)
        info.dpi_y = float(vres)
        info.compression = "RLE" if encoding == 1 else "без сжатия"

        if nplanes == 3 and bpp == 8:
            info.color_type = "TrueColor (RGB)"
        elif nplanes == 4 and bpp == 8:
            info.color_type = "RGB + Alpha"
        elif nplanes == 1 and bpp == 8:
            info.color_type = "Indexed (256 цветов)"
        elif nplanes == 1 and bpp == 1:
            info.color_type = "Bilevel"
        else:
            info.color_type = f"{nplanes} плоскостей × {bpp} бит"

        info.extra["pcx_version"] = VERSIONS.get(version, f"код {version}")
        info.extra["bytes_per_line"] = bytes_per_line

    return info