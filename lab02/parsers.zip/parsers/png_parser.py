"""Ручной парсинг PNG.
Сигнатура: 89 50 4E 47 0D 0A 1A 0A
Каждый чанк: length(4 BE), type(4), data(length), crc(4)
IHDR (13 байт): width(4), height(4), bit_depth(1), color_type(1),
                compression(1), filter(1), interlace(1)
Конец файла должен содержать чанк IEND.
"""

import os
from .base import (ImageInfo, read_exact, u32_be, FileTooShortError)

PNG_SIG = b"\x89PNG\r\n\x1a\n"

COLOR_TYPES = {
    0: "Grayscale",
    2: "TrueColor (RGB)",
    3: "Indexed (палитра)",
    4: "Grayscale + Alpha",
    6: "TrueColor + Alpha (RGBA)",
}


def parse(path: str) -> ImageInfo:
    info = ImageInfo(filename=os.path.basename(path), format="PNG")
    info.file_size = os.path.getsize(path)

    with open(path, "rb") as f:
        sig = f.read(8)
        if sig != PNG_SIG:
            info.status = "Файл повреждён: неверная сигнатура PNG"
            return info

        # Первый чанк всегда IHDR
        length = u32_be(read_exact(f, 4))
        ctype = read_exact(f, 4)
        if ctype != b"IHDR":
            info.status = "Файл повреждён: первый чанк не IHDR"
            return info
        data = read_exact(f, length)
        _ = read_exact(f, 4)  # CRC

        info.width  = u32_be(data[0:4])
        info.height = u32_be(data[4:8])
        bit_depth   = data[8]
        color_type  = data[9]
        compression = data[10]
        filter_m    = data[11]
        interlace   = data[12]

        info.bit_depth = bit_depth
        info.color_type = COLOR_TYPES.get(color_type, f"Неизвестный ({color_type})")
        info.compression = "Deflate (встроен в PNG)"
        info.extra["filter_method"] = filter_m
        info.extra["interlace"] = "Adam7" if interlace else "нет"

        # --- PHYs (DPI) ---
        # Ищем чанк PHYs для получения DPI. Пропускаем остальные чанки.
        while True:
            hdr = f.read(8)
            if len(hdr) < 8:
                info.status = "Файл повреждён: не найден чанк IEND"
                break
            ln = u32_be(hdr[0:4])
            ct = hdr[4:8]
            if ct == b"PHYs":
                d = read_exact(f, ln)
                ppu_x = u32_be(d[0:4])
                ppu_y = u32_be(d[4:8])
                unit  = d[8]
                if unit == 1:  # метры
                    info.dpi_x = round(ppu_x * 0.0254, 2)
                    info.dpi_y = round(ppu_y * 0.0254, 2)
                f.seek(4, 1)  # CRC
            elif ct == b"PLTE":
                info.extra["colors_in_palette"] = ln // 3
                f.seek(ln + 4, 1)
            elif ct == b"IEND":
                break
            else:
                f.seek(ln + 4, 1)   # пропустить data + CRC

    return info